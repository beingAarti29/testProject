from django.db import models
from wagtail.admin.edit_handlers import FieldPanel
from wagtail.core.models import Page

class MenusPage(Page):
 """it is a menu page"""

 template = "menus/menus_page.html"

 menus_title = models.CharField(max_length=100, blank=False, null=True) 
 subtitle = models.CharField(max_length=100, null=True, blank=True)

 content_panels = Page.content_panels + [
        FieldPanel("menus_title"),
        FieldPanel("subtitle")
]

class Meta:

        verbose_name = "Menu Page"
        verbose_name_plural = "Menu pages"